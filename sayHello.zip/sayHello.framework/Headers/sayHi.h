//
//  sayHello.h
//  sayHello
//
//  Created by liuxiyuan on 2018/11/12.
//  Copyright © 2018 liuxiyuan. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface sayHi : NSObject

- (void)sayHi;

@end

NS_ASSUME_NONNULL_END
