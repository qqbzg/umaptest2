//
//  sayHello.h
//  sayHello
//
//  Created by liuxiyuan on 2018/11/12.
//  Copyright © 2018 liuxiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for sayHello.
FOUNDATION_EXPORT double sayHelloVersionNumber;

//! Project version string for sayHello.
FOUNDATION_EXPORT const unsigned char sayHelloVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <sayHello/PublicHeader.h>

#import <sayHello/sayHi.h>
